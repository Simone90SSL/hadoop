import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.ToolRunner;


public class Topk {

	public static void main(String[] args) throws Exception {
		
		List<String> otherArgs = new ArrayList<String>();

		Configuration conf = new Configuration();
		
		for(int i=0; i < args.length; ++i) {
			try {
				if ("-r".equals(args[i])) {
					conf.setInt("mapreduce.job.reduces", Integer.parseInt(args[++i]));
				} else {
					otherArgs.add(args[i]);
				}
			} catch (NumberFormatException except) {
				System.out.println("ERROR: Integer expected instead of " + args[i]);
			}
		}

		Path input = new Path(otherArgs.get(0));
		Path output =new Path(otherArgs.get(1));
		
		Job job = Job.getInstance(conf);
        job.setJarByClass(Topk.class);
        job.setJobName("Topk");
        
	    FileInputFormat.addInputPath(job, input);
	    FileOutputFormat.setOutputPath(job, output);

	    job.setMapperClass(MyMapper.class);
	    job.setReducerClass(MyReducer.class);

	    job.setInputFormatClass(TextInputFormat.class);
	    
        job.setMapOutputKeyClass(ProductPair.class);
        job.setMapOutputValueClass(IntWritable.class);
        
        job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(Text.class);
  
	    job.waitForCompletion(true);
        
        // Second job
        job = Job.getInstance();
        job.setJarByClass(Topk.class);
        job.setJobName("GetTopk");
        
	    FileInputFormat.addInputPath(job, new Path(otherArgs.get(1)));
	    FileOutputFormat.setOutputPath(job, new Path(otherArgs.get(1)+"_TOP_K"));

	    job.setMapperClass(TopkMapper.class);
	    job.setReducerClass(TopkReducer.class);

	    job.setInputFormatClass(TextInputFormat.class);
        
        job.setMapOutputKeyClass(IntWritable.class);
        job.setMapOutputValueClass(ProductPair.class);
	    
        job.setOutputKeyClass(IntWritable.class);
	    job.setOutputValueClass(Text.class);    

	    job.waitForCompletion(true);
	}
	
	public static class MyMapper extends Mapper<LongWritable, Text, ProductPair, IntWritable>{
		private final static IntWritable one = new IntWritable(1);
        
		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			String userInf = value.toString();
            String[] userInfArray = userInf.split("\\s+");
            System.out.println("[MY_MAPPER] "+userInf);
            for(int i=1; i<userInfArray.length; i++)
                for(int j=i+1; j<userInfArray.length; j++){
                    context.write(new ProductPair(Integer.parseInt(userInfArray[i]), Integer.parseInt(userInfArray[j])), one);
                    context.write(new ProductPair(Integer.parseInt(userInfArray[j]), Integer.parseInt(userInfArray[i])), one);
                }
       	}
	}
	
	public static class MyReducer extends Reducer<ProductPair, IntWritable, Text, Text>{

		@Override
		protected void reduce(ProductPair key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			int sum = 0;
			for (IntWritable value : values) {
				sum += 1;
			}
            System.out.println("[MY_REDUCER] "+key.toString()+" "+sum);
			context.write(new Text(""+key.getProd1()), new Text(key.getProd2()+" "+sum));
		}
	}
    
    public static class TopkMapper extends Mapper<LongWritable, Text, IntWritable, ProductPair>{
		private final static IntWritable one = new IntWritable(1);
        
		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			String userInf = value.toString();
            System.out.println("[TopkMapper] "+userInf);
            String[] userInfArray = userInf.split("\\s+");
            context.write(new IntWritable(Integer.parseInt(userInfArray[0])), new ProductPair(
                        Integer.parseInt(userInfArray[1]), Integer.parseInt(userInfArray[2])));
            }
	}
	
	public static class TopkReducer extends Reducer<IntWritable, ProductPair, IntWritable, Text>{

        private static final int K = 10;
		@Override
		protected void reduce(IntWritable key, Iterable<ProductPair> values, Context context)
				throws IOException, InterruptedException {
			
            TreeMap<Integer, List<Integer>> heap = new TreeMap<Integer, List<Integer>>();
            for (ProductPair value : values) {
                System.out.println("[TOPK_REDUCER for "+key+"] "+value);    
                if(heap.get(value.getProd2())==null)
                   heap.put(value.getProd2(), new LinkedList<Integer>()); 
				heap.get(value.getProd2()).add(value.getProd1());
			}
            
            
            String topkString = "";
            Integer lastKey = 0;
            List<Integer> p;
            int i = 0;
            while(i<K && heap.size()>0){
                lastKey = heap.lastKey();
                p = heap.remove(lastKey);
                topkString += p+", ";
                i++;
            }
            context.write(key, new Text(topkString));
            
		}
	}
}
