import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.ToolRunner;


public class ProductPair implements WritableComparable {

       private int prod1;
       private int prod2;
       
       public ProductPair(){
        }
        
       public ProductPair(int p1, int p2){
            this.prod1 = p1;
            this.prod2 = p2;
        
        }
        
        public int getProd1(){
            return prod1;
        }
        
        public int getProd2(){
            return prod2;
        }
       
       public void write(DataOutput out) throws IOException {
         out.writeInt(prod1);
         out.writeInt(prod2);
       }
       
       public void readFields(DataInput in) throws IOException {
         prod1 = in.readInt();
         prod2 = in.readInt();
       }
       
       public int compareTo(Object p) {
         ProductPair o = (ProductPair)p;
         if(this.prod1<o.prod1)
            return -1;
         if(this.prod1>o.prod1)
            return 1;
         if(this.prod2<o.prod2)
            return -1;
         if(this.prod2>o.prod2)
            return 1;
         return 0;
       }

       public int hashCode() {
         final int prime = 31;
         int result = 1;
         result = prime * result + prod1;
         result = prime * result + prod2;
         return result;
       }    
       
       public String toString(){
            return prod1+" "+prod2;
        }
}
